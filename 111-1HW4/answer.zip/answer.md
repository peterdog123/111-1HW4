﻿# 第4次作業-作業-HW4
>
>學號：109111119 
><br />
>姓名：唐睿翔 
><br />
>作業撰寫時間：30 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2022/12/14
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x]說明內容
- [x]個人認為完成作業須具備觀念

## 說明程式與內容


```csharp
public partial class WebForm1 : System.Web.UI.Page
    {
        Sqlconnection s_Conns = new Sqlconnection(ConfigurationManager.ConnectionStrings["MSSQLLocalDB"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                s_Conns.open();
                SqlDataAdapter o_A = new SqlDataAdapter("SELECT * from Users", s_Conns);
                DataSet o_Set = new DataSet();
                o_A.Fill(o_Set,"zz");
                gd_View.DataSource = o_Set;
                gd_View.DataBind();
                s_Conns.Close();
            }
            catch (Exception ex){
                Response.Write(ex.ToString());
            }
        }

        protected System.Void btn_Insert_Click()
        {
            try
            {
                s_Conns.open();
                SqlCommand scom = new SqlCommand("Insert into Users(Name, Brithday)"+ "Values(N'阿貓阿狗','2000/10/10');");
                scom.ExecuteNonQuery();
                s_Conns.close();
                Page_Load(sender, e);
            }
            catch(Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }
    }
```


```html
<body>
    <form id="form1" runat="server">
        <div>
            <asp:Button ID="btn_Insert" runat="server" Text="點我新增資料夾" OnClick="btn_Insert_Click" />
            <asp:GridView ID="gd_View" runat="server"></asp:GridView>
        </div>
    </form>
</body>
```
```csharp
<configuration>
	<connectionStrings>
		<add name="MSSQLLocalDB" connectionString="Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=TEST;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False" /></connectionStrings>
```



## 個人認為完成作業須具備觀念

了解到如何建立資料庫，並了解許多Sql指令並運用。

